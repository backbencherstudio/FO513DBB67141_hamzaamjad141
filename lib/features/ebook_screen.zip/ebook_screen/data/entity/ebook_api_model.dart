class EbookApiModel {
  final String id;
  final String title;
  final String hostName;
  final DateTime date;
  final String pdf;
  final String cover;
  final DateTime createdAt;
  final DateTime updatedAt;

  EbookApiModel({
    required this.id,
    required this.title,
    required this.hostName,
    required this.date,
    required this.pdf,
    required this.cover,
    required this.createdAt,
    required this.updatedAt,
  });

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'hostName': hostName,
      'date': date.toIso8601String(),
      'mp3': pdf,
      'cover': cover,
      'createdAt': createdAt.toIso8601String(),
      'updatedAt': updatedAt.toIso8601String(),
    };
  }

  factory EbookApiModel.fromJson(Map<String, dynamic> json) {
    return EbookApiModel(
      id: json['id'] ?? '',
      title: json['title'] ?? '',
      hostName: json['hostName'] ?? '',
      date: DateTime.parse(json['date']),
      pdf: json['mp3'] ?? '',
      cover: json['cover'] ?? '',
      createdAt: DateTime.parse(json['createdAt']),
      updatedAt: DateTime.parse(json['updatedAt']),
    );
  }
}
